<?php
$bconn = mysqli_connect("localhost","root","","borrower");
?>