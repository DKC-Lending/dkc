<?php
$uconn = mysqli_connect("localhost","root","","dkc");
?>