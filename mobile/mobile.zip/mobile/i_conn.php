<?php
$iconn = mysqli_connect("localhost","root","","investmentpost");
?>